// GPL License - see http://opensource.org/licenses/gpl-license.php
// Copyright 2006 *nixCoders team - don't forget to credit us

#include <dis-asm.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <unistd.h>

typedef u_int32_t ptr_size_t;	// for x86
//typedef u_int64_t ptr_size_t;	// for ia64 need test

// Helper macro
#define GET_PAGE(addr) ((void *)(((ptr_size_t)addr) & ~((ptr_size_t)(getpagesize() - 1))))
#define unprotect(addr) (mprotect(GET_PAGE(addr), getpagesize(), PROT_READ | PROT_WRITE | PROT_EXEC))
#define reprotect(addr) (mprotect(GET_PAGE(addr), getpagesize(), PROT_READ | PROT_EXEC))

// Disassembler callbacks
int my_buffer_read_memory(bfd_vma from, bfd_byte *to, unsigned int length, struct disassemble_info *info) {
	memcpy((void *)to, (void *)(ptr_size_t)from, length);
	return 0;
}

void my_perror_memory(int status, bfd_vma memaddr, struct disassemble_info *info) {
	info->fprintf_func(info->stream, "ghf: Unknown error %d\n", status);
	exit(1);
}

// For disable disassembler output
fprintf_ftype my_fprintf(FILE *stream, const char *format, ...) {
	return 0;
}

// Return the length of the instruction
int disassemble_x86(void *addr) {
	// Initialize info for disassembler
	disassemble_info info;
	init_disassemble_info(&info, stdout, (fprintf_ftype)my_fprintf);
	info.mach = bfd_mach_i386_i386;
	info.read_memory_func = my_buffer_read_memory;
	info.memory_error_func = my_perror_memory;

	// Disassemble instruction
	return print_insn_i386((bfd_vma)(ptr_size_t)addr, &info);
}


#define ASM_JUMP_SIZE 5

void *detourFunction(void *orig, void *det) {

	int iLen = 0;
	while (iLen < ASM_JUMP_SIZE) {
		int len = disassemble_x86(orig + iLen);
		if (len < 0) {
			printf("error: can't disassemble at %p\n", orig);
			return NULL;
		}
		iLen += len;
	}

	// Backup instructions before it's override by the jump
	void *tramp = malloc(iLen + ASM_JUMP_SIZE);
	memcpy(tramp, orig, iLen);

	// Write a jump to the original function after the backuped intructions
	*(unsigned char *)(tramp + iLen) = 0xe9;
	*((void **)(tramp + iLen + 1)) = (void *)((((ptr_size_t)orig) + iLen) - (ptr_size_t)(tramp + iLen + ASM_JUMP_SIZE));

	// Write a jump to the detour at the original function
	unprotect(orig);
	*(unsigned char *)orig = 0xe9;
	*((void **)((ptr_size_t)orig + 1)) = (void *)(((ptr_size_t)det) - (((ptr_size_t)orig) + ASM_JUMP_SIZE));
	reprotect(orig);

	return tramp;
}

void undetourFunction(void *orig, void *tramp) {
	int iLen = 0;
	while (iLen < ASM_JUMP_SIZE)
		iLen += disassemble_x86(tramp + iLen);

	unprotect(orig);
	memcpy(orig, tramp, iLen);
	reprotect(orig);

	free(tramp);
}


int nopInstruction(void *addr) {
	unsigned int size = disassemble_x86(addr);

	unprotect(addr);
	int count = 0;
	for (; count < size; count++)
		*(unsigned char *)(addr + count) = 0x90;
	reprotect(addr);

	return size;
}
