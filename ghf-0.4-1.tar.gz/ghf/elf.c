#include <fcntl.h>
#include <gelf.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h> 

// Get symbol from an ELF .symtab section. If filename is NULL, the current process is use.
// Return NULL if the symbol is not found
void *getSymbolAddr(char *symbol, char *filename) {
	if (elf_version(EV_CURRENT) == EV_NONE) {
		fprintf(stderr, "ghf: error: Outdated libelf.\n");
		exit(1);
	}
	
	if (!filename)
		filename = "/proc/self/exe";	// Maybe use elf_memory()

	int fd = open(filename, O_RDONLY);
	Elf *elf = elf_begin(fd, ELF_C_READ, NULL);

	if (!elf) {
		fprintf(stderr, "ghf: error: Invalid ELF\n");
		exit(1);
	}
	
	void *result = NULL;
	
	// Loop throught sections
	Elf_Scn *scn = NULL;
	while ((scn = elf_nextscn(elf, scn)) != NULL) {
		GElf_Shdr shdr;
		gelf_getshdr(scn, &shdr);
		// Search .symtab sections
		if (shdr.sh_type == SHT_SYMTAB) {
			Elf_Data *data = elf_getdata(scn, NULL);
			
			// Search the symbol
			int count = 0;
			for (; count < (shdr.sh_size / shdr.sh_entsize); count++) {
				GElf_Sym sym;
				gelf_getsym(data, count, &sym);

				if (!strcmp(elf_strptr(elf, shdr.sh_link, sym.st_name), symbol)) {
					result = (void *)(unsigned int)sym.st_value;
					break;
				}
			}
		}
	}
	
	elf_end(elf);
	close(fd);

	return result;
}

int pltHook(char *symbol, void *hook) {
	if (elf_version(EV_CURRENT) == EV_NONE) {
		fprintf(stderr, "ghf: error: Outdated libelf.\n");
		exit(1);
	}
	
	int fd = open("/proc/self/exe", O_RDONLY);
	Elf *elf = elf_begin(fd, ELF_C_READ, NULL);

	if (!elf) {
		fprintf(stderr, "ghf: error: Invalid ELF.\n");
		exit(1);
	}
	
	int symbolHash = -1;
	int result = 0;
	
	// Find .symtab sections
	Elf_Scn *scn = NULL;
	while ((scn = elf_nextscn(elf, scn)) != NULL) {
		GElf_Shdr shdr;
		gelf_getshdr(scn, &shdr);
		// Search .symtab section
		if (shdr.sh_type == SHT_DYNSYM) {
			Elf_Data *data = elf_getdata(scn, NULL);
			
			// Search the symbol
			int count = 0;
			for (; count < (shdr.sh_size / shdr.sh_entsize); count++) {
				GElf_Rel rel;
				gelf_getrel(data, count, &rel);

				GElf_Sym sym;
				gelf_getsym(data, count, &sym);
				if (!strcmp(elf_strptr(elf, shdr.sh_link, sym.st_name), symbol)) {
					symbolHash = count;
					break;
				}
			}
		} else if (shdr.sh_type == SHT_REL) {
			Elf_Data *data = elf_getdata(scn, NULL);
			
			// Search the symbol
			int count = 0;
			for (; count < (shdr.sh_size / shdr.sh_entsize); count++) {
				GElf_Rel rel;
				gelf_getrel(data, count, &rel);

				if (ELF64_R_SYM(rel.r_info) == symbolHash) {
					*(void **)(unsigned int)rel.r_offset = hook;
					result = 1;
					break;
				}
			}
		}
	}
	
	elf_end(elf);
	close(fd);

	return result;
}
